/**
 * ملف تشغيل البدء لبيئة الإنتاج
 * 
 * يتم استخدام هذا الملف عند تشغيل التطبيق على Render.com
 * بدلاً من تشغيل الخادم مباشرة
 */

const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

// تحقق من وجود ملفات مجمعة المشروع
const distPath = path.join(__dirname, 'dist');
const distExists = fs.existsSync(distPath);

if (!distExists) {
  console.log('البناء غير موجود، جارٍ بناء المشروع...');
  
  // تنفيذ أمر البناء
  exec('npm run build', (error, stdout, stderr) => {
    if (error) {
      console.error(`خطأ في البناء: ${error}`);
      return;
    }
    
    console.log(`نتيجة البناء: ${stdout}`);
    
    if (stderr) {
      console.error(`أخطاء البناء: ${stderr}`);
    }
    
    // بعد اكتمال البناء، شغّل الخادم
    startServer();
  });
} else {
  // إذا كان البناء موجودًا بالفعل، شغّل الخادم مباشرة
  startServer();
}

// وظيفة لتشغيل الخادم
function startServer() {
  console.log('بدء تشغيل الخادم...');
  
  // استيراد ملف الخادم الرئيسي
  require('./dist/server/index.js');
  
  console.log(`الخادم يعمل على المنفذ ${process.env.PORT || 3000}`);
}