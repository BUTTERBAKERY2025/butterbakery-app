# ButterBakery Operations Platform

This package contains the complete ButterBakery Operations Platform ready for deployment on Render.com.

## Deployment Instructions

Please refer to one of the following deployment guides:

- [Arabic Deployment Guide](./RENDER_DIRECT_DEPLOY_V3.md)
- [English Deployment Guide](./RENDER_DIRECT_DEPLOY_V3_EN.md)

## Default Login Credentials

- Username: `admin`
- Password: `admin`

**Important**: Change the default password immediately after your first login.

