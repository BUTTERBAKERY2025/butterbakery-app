/**
 * أداة للتحقق من صحة الاتصال بقاعدة البيانات
 * 
 * يمكن تشغيل هذا الملف عبر:
 * node deploy/check_database.js
 * 
 * يقوم هذا السكريبت بالتحقق من:
 * - صحة الاتصال بقاعدة البيانات
 * - قائمة الجداول الموجودة
 * - عدد الصفوف في كل جدول
 */

const { Client } = require('pg');

async function main() {
  console.log('جاري التحقق من صحة الاتصال بقاعدة البيانات...');
  
  // قراءة رابط قاعدة البيانات من متغيرات البيئة
  const databaseUrl = process.env.DATABASE_URL;
  
  if (!databaseUrl) {
    console.error('خطأ: متغير البيئة DATABASE_URL غير موجود');
    console.log('يرجى التأكد من تعيين متغير البيئة DATABASE_URL بشكل صحيح.');
    process.exit(1);
  }
  
  const client = new Client({
    connectionString: databaseUrl,
    // إضافة خيارات SSL إذا كان الاتصال بقاعدة بيانات على Render.com
    ssl: databaseUrl.includes('render.com') ? {
      rejectUnauthorized: false
    } : undefined
  });
  
  try {
    // الاتصال بقاعدة البيانات
    console.log('جاري الاتصال بقاعدة البيانات...');
    await client.connect();
    console.log('✅ تم الاتصال بقاعدة البيانات بنجاح!');
    
    // التحقق من الجداول الموجودة
    console.log('\nقائمة الجداول الموجودة:');
    const tablesResult = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
      ORDER BY table_name;
    `);
    
    if (tablesResult.rows.length === 0) {
      console.log('⚠️ لا توجد جداول في قاعدة البيانات');
    } else {
      const tables = tablesResult.rows.map(row => row.table_name);
      console.log(tables.join('\n'));
      
      // التحقق من عدد الصفوف في كل جدول
      console.log('\nعدد الصفوف في كل جدول:');
      for (const table of tables) {
        const countResult = await client.query(`SELECT COUNT(*) FROM "${table}"`);
        const count = countResult.rows[0].count;
        console.log(`${table}: ${count} صف`);
      }
    }
    
    // التحقق من إصدار قاعدة البيانات
    const versionResult = await client.query('SELECT version()');
    console.log('\nإصدار قاعدة البيانات:');
    console.log(versionResult.rows[0].version);
    
  } catch (error) {
    console.error('❌ خطأ في الاتصال بقاعدة البيانات:');
    console.error(error.message);
    console.log('\nنصائح للتصحيح:');
    console.log('- تأكد من أن متغير البيئة DATABASE_URL صحيح');
    console.log('- تأكد من أن قاعدة البيانات تعمل وفي حالة جيدة');
    console.log('- تأكد من أن المستخدم لديه صلاحيات الوصول المناسبة');
    console.log('- تحقق من إعدادات الجدار الناري وقواعد الوصول');
  } finally {
    // إغلاق الاتصال
    await client.end();
    console.log('\nتم إغلاق الاتصال بقاعدة البيانات');
  }
}

main();