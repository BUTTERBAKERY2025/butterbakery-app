#!/bin/bash

# سكريبت لتجهيز نسخة النشر لـ Render.com

echo "جاري تجهيز مشروع ButterBakery-OP للنشر على Render.com..."

# إنشاء مجلد مؤقت
TEMP_DIR="$(pwd)/deploy/temp_bundle"
mkdir -p $TEMP_DIR

# تحديد المسار الرئيسي للمشروع
REPO_DIR="/home/runner/workspace"
echo "المسار الرئيسي للمشروع: $REPO_DIR"
echo "نسخ ملفات المشروع..."

# استخدام المسار المطلق للمجلدات الرئيسية
for dir in $REPO_DIR/client $REPO_DIR/server $REPO_DIR/shared $REPO_DIR/public; do
  DIR_NAME=$(basename "$dir")
  if [ -d "$dir" ]; then
    cp -r "$dir" "$TEMP_DIR/"
    echo "✅ تم نسخ $DIR_NAME"
  else
    echo "❌ $DIR_NAME غير موجود، تخطي النسخ"
  fi
done

# نسخ الملفات الأساسية إذا كانت موجودة
for file in package.json package-lock.json tsconfig.json vite.config.ts tailwind.config.ts postcss.config.js drizzle.config.ts render.yaml README.md; do
  if [ -f "$REPO_DIR/$file" ]; then
    cp "$REPO_DIR/$file" "$TEMP_DIR/"
    echo "✅ تم نسخ $file"
  else
    echo "❌ $file غير موجود، تخطي النسخ"
  fi
done

# إنشاء ملف render.yaml إذا لم يكن موجودًا
if [ ! -f "$TEMP_DIR/render.yaml" ]; then
  echo "ℹ️ إنشاء ملف render.yaml..."
  cat > "$TEMP_DIR/render.yaml" << EOL
services:
  - type: web
    name: butter-bakery
    env: node
    plan: starter
    buildCommand: npm install
    startCommand: npm start
    healthCheckPath: /health
    autoDeploy: true
    envVars:
      - key: NODE_ENV
        value: production
      - key: PORT
        value: 5000
      - key: DATABASE_URL
        fromDatabase:
          name: butter-bakery-db
          property: connectionString
    
databases:
  - name: butter-bakery-db
    plan: starter
    postgresMajorVersion: 15
EOL
  echo "✅ تم إنشاء ملف render.yaml بنجاح"
fi

# إنشاء ملف نصي يحتوي على معلومات النشر
cat > "$TEMP_DIR/DEPLOY.md" << EOL
# تعليمات النشر

هذا ملف تم إنشاؤه تلقائيًا بواسطة سكريبت التجهيز للنشر.

## الخطوات المطلوبة بعد النشر:

1. تأكد من إعداد متغيرات البيئة في لوحة تحكم Render.com.
2. تحقق من اتصال قاعدة البيانات باستخدام النقطة النهائية /health.
3. قم بتنفيذ أوامر الهجرة اللازمة لقاعدة البيانات إذا لزم الأمر.

تاريخ إنشاء هذه الحزمة: $(date)
EOL

# نسخ سكريبت check_database.js
if [ -f "$REPO_DIR/deploy/check_database.js" ]; then
  cp "$REPO_DIR/deploy/check_database.js" "$TEMP_DIR/"
  echo "✅ تم نسخ سكريبت التحقق من قاعدة البيانات"
fi

# إنشاء ملف start.js لتشغيل الخادم
cat > "$TEMP_DIR/start.js" << EOL
/**
 * سكريبت بدء تشغيل التطبيق على Render.com
 */
console.log('بدء تشغيل تطبيق ButterBakery-OP...');
console.log('البيئة:', process.env.NODE_ENV);
console.log('المنفذ:', process.env.PORT || 5000);

// التحقق من وجود متغير بيئة قاعدة البيانات
if (!process.env.DATABASE_URL) {
  console.error('تحذير: متغير البيئة DATABASE_URL غير موجود!');
}

// تنفيذ ملف التطبيق الرئيسي
require('./server');
EOL

# تجهيز ملف بسيط للنشر
echo "تجهيز ملف النشر..."

# إنشاء ملف package.json للنشر إذا لم يكن موجودًا
if [ ! -f "$TEMP_DIR/package.json" ]; then
  echo "ℹ️ إنشاء ملف package.json للنشر..."
  cat > "$TEMP_DIR/package.json" << EOL
{
  "name": "butter-bakery-op",
  "version": "1.0.0",
  "description": "نظام إدارة مخبز الزبدة",
  "main": "server/index.js",
  "scripts": {
    "start": "node start.js",
    "test": "echo \\"Error: no test specified\\" && exit 1"
  },
  "engines": {
    "node": ">=18.0.0"
  },
  "keywords": ["bakery", "management", "arabic"],
  "author": "Replit AI",
  "license": "ISC"
}
EOL
  echo "✅ تم إنشاء ملف package.json"
fi

# إنشاء ملف .gitignore للنشر
cat > "$TEMP_DIR/.gitignore" << EOL
node_modules
.env
.DS_Store
*.log
EOL

# إنشاء ملف تكوين Render للنشر
echo "جاري إنشاء ملف render.yaml للنشر..."
cat > "$TEMP_DIR/render.yaml" << EOL
services:
  - type: web
    name: butter-bakery-op
    env: node
    plan: starter
    buildCommand: npm install
    startCommand: npm start
    healthCheckPath: /health
    autoDeploy: true
    envVars:
      - key: NODE_ENV
        value: production
      - key: PORT
        value: 5000
      - key: DATABASE_URL
        fromDatabase:
          name: butter-bakery-db
          property: connectionString
    
databases:
  - name: butter-bakery-db
    plan: starter
    postgresMajorVersion: 15
EOL

# إنشاء ملف README.md للنشر
cat > "$TEMP_DIR/README.md" << EOL
# نظام إدارة مخبز الزبدة

نظام متكامل لإدارة عمليات المخبز، المبيعات، والتقارير، مع واجهة عربية وإنجليزية سهلة الاستخدام.

## الميزات الرئيسية

- إدارة المبيعات اليومية
- إدارة صندوق النقدية
- تقارير مبيعات متقدمة
- مراقبة أنظمة قواعد البيانات
- واجهة متعددة اللغات (العربية/الإنجليزية)

## متطلبات النشر

- Node.js v18+
- قاعدة بيانات PostgreSQL

## إعداد بيئة التشغيل

قم بإعداد المتغيرات البيئية التالية:

\`\`\`
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://...
\`\`\`

## بدء التشغيل

\`\`\`
npm install
npm start
\`\`\`
EOL

# حزم الملفات يدوياً
echo "🔄 جاري ضغط ملفات المشروع... (قد يستغرق بعض الوقت)"
CURRENT_DIR=$(pwd)
ZIP_FILE="$CURRENT_DIR/butter-bakery-deploy.zip"
cd "$TEMP_DIR"

# استخدام الأمر zip مباشرة
zip -r "$ZIP_FILE" .
ZIP_STATUS=$?

cd "$CURRENT_DIR"

# التحقق من نجاح عملية الضغط
if [ $ZIP_STATUS -eq 0 ] && [ -f "$ZIP_FILE" ]; then
  # تسمية الملف المضغوط بناءً على التاريخ
  TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
  FINAL_ZIP="$CURRENT_DIR/butter-bakery-$TIMESTAMP.zip"
  mv "$ZIP_FILE" "$FINAL_ZIP"
  
  echo "تنظيف المجلدات المؤقتة..."
  rm -rf "$TEMP_DIR"
  
  # عرض معلومات حول ملف الضغط
  SIZE=$(du -h "$FINAL_ZIP" | cut -f1)
  echo "✅ تم الانتهاء بنجاح!"
  echo "📦 تم إنشاء ملف الضغط: $FINAL_ZIP"
  echo "📊 حجم الملف: $SIZE"
  echo ""
  echo "🚀 الخطوات التالية للنشر على Render.com:"
  echo "1. انتقل إلى لوحة تحكم Render.com وأنشئ تطبيق Web Service جديد"
  echo "2. اختر طريقة النشر 'Upload' وارفع ملف الضغط الذي تم إنشاؤه"
  echo "3. أكمل إعداد التطبيق حسب المعلومات المذكورة في ملف DEPLOY.md"
else
  echo "❌ فشل إنشاء ملف الضغط. المجلد المؤقت موجود في $TEMP_DIR"
  echo "حاول استخدام أداة ضغط أخرى لضغط محتويات المجلد المؤقت."
fi