/**
 * ملف بدء تشغيل الخادم المركزي لـ ButterBakery
 * يستخدم هذا الملف لبدء تشغيل التطبيق على منصة Render.com
 * 
 * تم تصميم هذا الملف ليعمل في بيئة الإنتاج على Render.com
 * ويوفر معالجة متدرجة للأخطاء ودعم المسارات المختلفة
 */

// طباعة رسائل بدء التشغيل
console.log(`🚀 بدء تشغيل منصة ButterBakery Operations`);
console.log(`📅 تاريخ ووقت التشغيل: ${new Date().toISOString()}`);
console.log(`📂 المسار الحالي: ${process.cwd()}`);

// وظيفة تحميل وحدة مع معالجة الأخطاء والبدائل
function requireWithFallback(moduleName) {
  try {
    return require(moduleName);
  } catch (error) {
    console.error(`❌ خطأ في تحميل الوحدة '${moduleName}':`, error.message);
    return null;
  }
}

// محاولة تحميل وحدة express
const express = requireWithFallback('express');
if (!express) {
  console.error('⚠️ فشل تحميل express، سيتم استخدام http الأساسي');
}

// محاولة تحميل وحدات النظام الأساسية
const fs = requireWithFallback('fs');
const path = requireWithFallback('path');
const http = requireWithFallback('http');

// فحص وجود ملفات المشروع الرئيسية
function checkFileExists(filePath) {
  if (!fs) return false;
  
  try {
    return fs.existsSync(filePath);
  } catch (error) {
    console.error(`❌ خطأ في فحص وجود الملف '${filePath}':`, error.message);
    return false;
  }
}

// قائمة المسارات المحتملة للملف الرئيسي
const possibleServerPaths = [
  './server/index.js',
  './server/index.ts',
  'server/index.js',
  '/opt/render/project/src/server/index.js',
  '../server/index.js',
];

// محاولة تحميل الملف الرئيسي من أحد المسارات المحتملة
function startServer() {
  // طباعة معلومات النظام
  console.log(`🔍 معلومات النظام:`);
  console.log(`   - Node.js: ${process.version}`);
  console.log(`   - OS: ${process.platform} ${process.arch}`);
  console.log(`   - ENV: ${process.env.NODE_ENV || 'غير محدد'}`);

  // فحص وجود ملفات المشروع
  console.log(`🔍 فحص ملفات المشروع...`);
  
  if (fs) {
    try {
      const rootFiles = fs.readdirSync('.');
      console.log(`📂 الملفات في المجلد الحالي: ${rootFiles.join(', ')}`);
      
      // فحص وجود مجلد server
      if (checkFileExists('./server')) {
        const serverFiles = fs.readdirSync('./server');
        console.log(`📂 الملفات في مجلد server: ${serverFiles.join(', ')}`);
      }
    } catch (error) {
      console.error('❌ خطأ في قراءة ملفات المجلد:', error.message);
    }
  }
  
  // محاولة استدعاء الملف الرئيسي
  console.log(`🔄 جاري محاولة تحميل الملف الرئيسي...`);
  
  let mainModuleLoaded = false;
  
  for (const serverPath of possibleServerPaths) {
    if (checkFileExists(serverPath)) {
      console.log(`✅ تم العثور على الملف: ${serverPath}`);
      
      try {
        console.log(`🔄 جاري تحميل الملف: ${serverPath}`);
        require(serverPath);
        console.log(`✅ تم تحميل الملف الرئيسي بنجاح: ${serverPath}`);
        mainModuleLoaded = true;
        break;
      } catch (error) {
        console.error(`❌ خطأ في تحميل الملف '${serverPath}':`, error.message);
      }
    } else {
      console.log(`⚠️ الملف غير موجود: ${serverPath}`);
    }
  }
  
  // في حالة عدم تحميل أي ملف رئيسي، تشغيل خادم بسيط للطوارئ
  if (!mainModuleLoaded) {
    console.log(`⚠️ لم يتم تحميل أي ملف رئيسي، سيتم تشغيل خادم بسيط للطوارئ`);
    
    if (express) {
      // إنشاء تطبيق express للطوارئ
      const app = express();
      const port = process.env.PORT || 3000;
      
      // إضافة مسار صحة
      app.get('/health', (req, res) => {
        res.status(200).json({
          status: 'ok',
          mode: 'emergency',
          timestamp: new Date().toISOString()
        });
      });
      
      // إضافة المسار الرئيسي
      app.get('/', (req, res) => {
        let fileList = 'غير متاح';
        
        if (fs) {
          try {
            fileList = fs.readdirSync('.').join('\n');
          } catch (error) {
            fileList = `خطأ في قراءة الملفات: ${error.message}`;
          }
        }
        
        res.send(`
          <!DOCTYPE html>
          <html dir="rtl">
          <head>
            <meta charset="utf-8">
            <title>ButterBakery - الخادم الاحتياطي</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
              h1 { color: #e65100; }
              .container { max-width: 800px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
              .info { background-color: #f5f5f5; padding: 10px; border-radius: 5px; }
              pre { background-color: #f0f0f0; padding: 10px; overflow: auto; }
            </style>
          </head>
          <body>
            <div class="container">
              <h1>منصة عمليات ButterBakery - الخادم الاحتياطي</h1>
              
              <div class="info">
                <p><strong>الوقت الحالي:</strong> ${new Date().toISOString()}</p>
                <p><strong>بيئة التشغيل:</strong> ${process.env.NODE_ENV || 'غير محدد'}</p>
                <p><strong>المسار الحالي:</strong> ${process.cwd()}</p>
                <p><strong>إصدار Node.js:</strong> ${process.version}</p>
              </div>
              
              <h2>محتويات المجلد الحالي</h2>
              <pre>${fileList}</pre>
              
              <h2>خطأ في تحميل التطبيق</h2>
              <p>لم يتم العثور على الملف الرئيسي للتطبيق. يرجى التحقق من هيكل الملفات.</p>
            </div>
          </body>
          </html>
        `);
      });
      
      // تشغيل الخادم
      app.listen(port, '0.0.0.0', () => {
        console.log(`🚨 تم تشغيل خادم الطوارئ على المنفذ ${port}`);
      });
    } else if (http) {
      // إنشاء خادم http بسيط في حالة عدم توفر express
      const port = process.env.PORT || 3000;
      
      const server = http.createServer((req, res) => {
        res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});
        res.end(`
          <!DOCTYPE html>
          <html>
          <head><title>ButterBakery - الخادم البسيط</title></head>
          <body>
            <h1>منصة عمليات ButterBakery - الخادم البسيط</h1>
            <p>الوقت: ${new Date().toISOString()}</p>
            <p>لم يتم العثور على ملفات التطبيق الرئيسية.</p>
          </body>
          </html>
        `);
      });
      
      server.listen(port, '0.0.0.0', () => {
        console.log(`🚨 تم تشغيل خادم HTTP البسيط على المنفذ ${port}`);
      });
    } else {
      console.error('❌ فشل في إنشاء أي خادم، لا يمكن متابعة التنفيذ.');
    }
  }
}

// تنفيذ وظيفة بدء التشغيل
startServer();

// التقاط الأخطاء غير المعالجة
process.on('uncaughtException', (err) => {
  console.error('❌ خطأ غير معالج:', err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ وعد مرفوض غير معالج:', reason);
});