# دليل النشر اليدوي على GitHub

## متطلبات النشر
- حساب على GitHub
- Git مثبت على جهازك (اختياري)

## طريقة 1: النشر عبر واجهة GitHub

1. قم بتسجيل الدخول إلى [GitHub](https://github.com)
2. انقر على زر "+" في الزاوية العلوية اليمنى واختر "New repository"
3. أدخل اسم المستودع (مثل "butterbakery-app")
4. اختر "Public" للمستودع العام أو "Private" للمستودع الخاص
5. اترك خيار "Add a README file" غير محدد
6. انقر على "Create repository"
7. في الصفحة التالية، انقر على "uploading an existing file"
8. اسحب وأفلت جميع ملفات هذا المجلد، أو انقر على مساحة السحب لاختيار الملفات يدويًا
9. أضف رسالة الالتزام (مثل "تنفيذ مشروع ButterBakery")
10. انقر على "Commit changes"

## طريقة 2: النشر باستخدام Git (للمستخدمين المتقدمين)

1. قم بتثبيت [Git](https://git-scm.com/downloads) إذا لم يكن مثبتًا بالفعل
2. قم بإنشاء مستودع جديد على GitHub (كما في الخطوات 1-6 أعلاه)
3. افتح موجه الأوامر (أو Terminal) وانتقل إلى مجلد المشروع:
   
   ```bash
   cd path/to/final_deploy_files
   ```

4. قم بتهيئة مستودع Git محلي:
   
   ```bash
   git init
   git add .
   git commit -m "تنفيذ مشروع ButterBakery"
   ```

5. أضف المستودع البعيد وادفع الملفات:
   
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/butterbakery-app.git
   git branch -M main
   git push -u origin main
   ```

   استبدل `YOUR_USERNAME` باسم المستخدم الخاص بك على GitHub و `butterbakery-app` باسم المستودع الذي أنشأته.

## النشر على Render.com من GitHub

1. قم بتسجيل الدخول إلى [Render.com](https://render.com)
2. انقر على "New" واختر "Web Service"
3. اختر "Build and deploy from a Git repository"
4. حدد المستودع الذي أنشأته
5. استخدم الإعدادات التالية:
   - Name: butterbakery-app
   - Region: اختر الأقرب إليك
   - Branch: main
   - Root Directory: /
   - Runtime: Node
   - Build Command: npm install && npm run build
   - Start Command: node start.js
6. اضبط متغيرات البيئة:
   - DATABASE_URL: رابط قاعدة بيانات PostgreSQL
   - PORT: 3000 (اختياري)
7. انقر على "Create Web Service"
