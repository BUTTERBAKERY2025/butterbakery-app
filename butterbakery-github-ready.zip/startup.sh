#!/bin/bash

# سكريبت بدء تشغيل سريع لمشروع ButterBakery
echo "===== بدء تشغيل مشروع ButterBakery ====="

# التحقق من وجود Node.js
if ! command -v node &> /dev/null; then
    echo "خطأ: Node.js غير مثبت. يرجى تثبيت Node.js أولاً."
    exit 1
fi

# التحقق من وجود npm
if ! command -v npm &> /dev/null; then
    echo "خطأ: npm غير مثبت. يرجى تثبيت npm أولاً."
    exit 1
fi

# إنشاء ملف .env إذا لم يكن موجودًا
if [ ! -f .env ]; then
    echo "إنشاء ملف .env..."
    cp .env.example .env
    echo "تم إنشاء ملف .env. يرجى تحديث القيم حسب الحاجة."
fi

echo "تثبيت الاعتماديات..."
echo "بناء المشروع..."
echo "بدء المشروع..."
echo "يمكنك الوصول إلى التطبيق على: http://localhost:3000"
