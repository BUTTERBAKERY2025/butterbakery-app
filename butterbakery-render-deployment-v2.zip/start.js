/**
 * ملف تشغيل البدء لبيئة الإنتاج
 * 
 * يتم استخدام هذا الملف عند تشغيل التطبيق على Render.com
 * بدلاً من تشغيل الخادم مباشرة
 */

// تحميل المتغيرات البيئية
require('dotenv').config();

const { log } = console;

// سجل معلومات البدء
log('🚀 بدء تشغيل تطبيق ButterBakery-OP في بيئة الإنتاج...');
log(`🕒 التاريخ والوقت: ${new Date().toISOString()}`);
log(`🌐 بيئة التشغيل: ${process.env.NODE_ENV}`);
log(`🔌 المنفذ: ${process.env.PORT || 10000}`);

// تعيين مسار الملف الرئيسي للتطبيق
const entryPoint = process.env.NODE_ENV === 'production' 
    ? './server/index.js' 
    : './server/index.ts';

// بدء التطبيق
function startServer() {
    try {
        log(`📂 تحميل نقطة البدء: ${entryPoint}`);
        
        // في بيئة الإنتاج، يجب تنفيذ الملف المجمع .js
        if (entryPoint.endsWith('.js')) {
            require(entryPoint);
        } else {
            // في بيئة التطوير، يمكن استخدام ts-node لتنفيذ ملفات TypeScript
            require('ts-node').register({
                transpileOnly: true
            });
            require(entryPoint);
        }
        
        log('✅ تم بدء التطبيق بنجاح');
    } catch (error) {
        log('❌ حدث خطأ أثناء بدء التطبيق:');
        console.error(error);
        process.exit(1);
    }
}

// التعامل مع إشارات الإيقاف
process.on('SIGINT', () => {
    log('🛑 تم استلام إشارة SIGINT، إيقاف التطبيق...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    log('🛑 تم استلام إشارة SIGTERM، إيقاف التطبيق...');
    process.exit(0);
});

// بدء التشغيل
startServer();